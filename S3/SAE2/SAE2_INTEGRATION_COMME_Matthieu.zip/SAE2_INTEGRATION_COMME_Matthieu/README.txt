Créer la corbeille avec : ./init-trashbox.sh 
Il existe deux versions de delete et restore :
	- "demo" pour vérifier la (dé)transposition avec un fichier texte
	- "sae" pour tout type de fichier. Cette version utilise uuencode et uudecode.
Supprimer : ./sae_delete.sh MDP fichier_1 [... fichier_n]
Restaurer : ./sae_restore.sh [option] MDP fichier_1 [... fichier_n]
		-r
			mode récursif qui restaure le fichier à son adressage d'origine
		-d OUTPUT
			restaure le fichier dans le dossier OUTPUT

Vous pouvez utiliser le fichier toto et exécuter les exemples imagés, 
ainsi que le dossier sandbox4trashbox pour tester la suppression de dossier et les options de restauration.
Ex: 
	supprimer un dossier : 		
		./sae_delete.sh clef sandbox4trashbox/d1/
	consulter la corbeille :	
		./sae_trashbox_ls.sh
	sans option, restaure restaure "file_1" le plus récent dans le répertoire courant
		./sae_restore.sh clef file_1
	changer d'output :
		./sae_restore.sh -d ../ clef file_1
	mode récursif :
		./sae_restore.sh -r clef dijkstra_10 dijkstra_9
